

<?php $__env->startSection('title', 'Blog || Spectrum Robotics'); ?>

<?php $__env->startSection('content'); ?>
    <!-- page-banner9 -->
    <section class="page-banner9">
        <div class="shape"></div>
        <div class="shape3"></div>
        <div class="staff-text">Articles</div>
        <div class="container">
            <div class="page-content">
                <h1 class="title">/ Blog /</h1>
            </div>
        </div>
        <ul class="breadcrumbs">
            <li><a href='<?php echo e(route('home')); ?>' title>Home</a></li>
            <li>/</li>
            <li>Blog</li>
        </ul>
    </section>
    <!-- End page-banner9 -->

    <!-- blog-sec -->
    <section class="blog-sec v2 ibt-section-gap">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-card">
                            <div class="blog-img">
                                <a href='<?php echo e(route('blog.single', $blog->slug)); ?>'><img
                                        src="<?php echo e($blog->featured_image ? asset($blog->featured_image) : asset('frontend/assets/images/blog/blog1-1.png')); ?>"
                                        alt="<?php echo e($blog->title); ?>"></a>
                                <span class="blog-meta"><?php echo e($blog->formatted_date); ?>

                                    <?php echo e($blog->author ? '/ ' . $blog->author : ''); ?></span>
                            </div>
                            <div class="blog-content">
                                <h4 class="title"><a href='<?php echo e(route('blog.single', $blog->slug)); ?>' title><?php echo e($blog->title); ?></a>
                                </h4>
                                <span>/ <?php echo e($blog->category ? $blog->category->name : 'General'); ?> /</span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <div class="alert alert-info">
                            <h4>No blog posts yet</h4>
                            <p>Check back soon for the latest updates and articles.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if($blogs->hasPages()): ?>
                <nav aria-label="Page navigation">
                    <?php echo e($blogs->links('pagination::bootstrap-4')); ?>

                </nav>
            <?php endif; ?>
        </div>
    </section>
    <!-- End blog-sec -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contact_section'); ?>
    <!-- contact-sec -->
    <div class="contact-sec ibt-section-gap">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="contact-content">
                        <div class="sec-title white">
                            <span class="sub-title">get in touch</span>
                            <h2 class="title animated-heading">We are always ready to help you and answer your
                                questions</h2>
                            <p>Have questions about our robotics solutions? Contact us today.</p>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="contact-info">
                                    <div class="call-center">
                                        <h4 class="title">Call Center</h4>
                                        <a href="tel:8003508431" class="nmbr">800 100 975 20 34</a>
                                    </div>
                                    <div class="call-center mb-0">
                                        <h4 class="title">Email</h4>
                                        <a href="mailto:info@spectrumrobotics.com"
                                            class="gmail">info@spectrumrobotics.com</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="contact-info">
                                    <div class="call-center">
                                        <h4 class="title">Our Location</h4>
                                        <p>USA, New York - 1060 <br>Str. First Avenue 1</p>
                                    </div>
                                    <div class="call-center mb-0">
                                        <h4 class="title">Social network</h4>
                                        <ul class="social-icon">
                                            <li><a href="https://www.facebook.com/" target="_blank" title=""><i
                                                        class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="http://www.twitter.com/" target="_blank" title=""><i
                                                        class="fab fa-twitter"></i></a></li>
                                            <li><a href="http://www.linkedin.com/" target="_blank" title=""><i
                                                        class="fab fa-linkedin-in"></i></a></li>
                                            <li><a href="https://www.youtube.com/" target="_blank" title=""><i
                                                        class="fab fa-youtube"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact-form">
                        <form action="#" method="post" class="custom-form">
                            <h2>Get in Touch</h2>
                            <input type="text" id="name" name="name" placeholder="Full name" required>
                            <input type="email" id="email" name="email" placeholder="Email" required>
                            <input type="text" id="subject" name="subject" placeholder="Subject" required>
                            <textarea id="message" name="message" rows="5" placeholder="Write your message..."
                                required></textarea>

                            <button type="submit" class="ibt-btn ibt-btn-outline">
                                <span>Send message</span>
                                <i class="icon-arrow-top"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End contact-sec -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Robotlab\robot\resources\views/frontend/blog.blade.php ENDPATH**/ ?>