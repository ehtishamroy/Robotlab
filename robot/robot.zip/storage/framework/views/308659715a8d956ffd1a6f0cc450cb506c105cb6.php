

<?php $__env->startSection('title', $blog->title . ' || Spectrum Robotics Blog'); ?>

<?php $__env->startSection('content'); ?>
    <!-- page-banner9 -->
    <section class="page-banner9">
        <div class="shape"></div>
        <div class="shape3"></div>
        <div class="staff-text">Articles</div>
        <div class="container">
            <div class="page-content">
                <h1 class="title"><?php echo e($blog->title); ?></h1>
            </div>
        </div>
        <ul class="breadcrumbs">
            <li><a href='<?php echo e(route('home')); ?>' title>Home</a></li>
            <li>/</li>
            <li><a href='<?php echo e(route('blog')); ?>' title>Blog</a></li>
            <li>/</li>
            <li><?php echo e(Str::limit($blog->title, 30)); ?></li>
        </ul>
    </section>
    <!-- End page-banner9 -->

    <!-- blog-sec4 -->
    <section class="blog-single ibt-section-gap">
        <button class="sidebar-toggle"></button>
        <!-- Overlay -->
        <div class="sidebar-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-9 col-lg-8">
                    <div class="blog-single-content">
                        <div class="blog-img4">
                            <?php if($blog->featured_image): ?>
                                <img src="<?php echo e(asset($blog->featured_image)); ?>" alt="<?php echo e($blog->title); ?>">
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/assets/images/blog/blog5-1.png')); ?>" alt="<?php echo e($blog->title); ?>">
                            <?php endif; ?>
                            <span class="blog-meta4"><?php echo e($blog->formatted_date); ?>

                                <?php echo e($blog->author ? '/ ' . $blog->author : ''); ?></span>
                        </div>

                        <div class="blog-content-body">
                            <?php echo $blog->content; ?>

                        </div>

                        <div class="post-meta2">
                            <?php if($blog->author): ?>
                                <h4 class="name">By <a href="#"><?php echo e($blog->author); ?></a></h4>
                            <?php endif; ?>
                            <?php if($blog->tags && count($blog->tags) > 0): ?>
                                <ul class="tag-list">
                                    <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="#" title="">/ <?php echo e($tag); ?> /</a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4">
                    <div class="side-bar2">
                        <button class="sidebar-close"></button>
                        <div class="form-widget side-widget2 mb-0">
                            <form action="<?php echo e(route('blog')); ?>" method="GET">
                                <input type="text" name="search" placeholder="Search" required>
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>

                        <?php if($recentPosts->count() > 0): ?>
                            <div class="post-widget side-widget2">
                                <h4 class="side-bar-title">Recent posts</h4>
                                <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="recent-post <?php echo e($loop->last ? 'mb-0' : ''); ?>">
                                        <?php if($recentPost->featured_image): ?>
                                            <img src="<?php echo e(asset($recentPost->featured_image)); ?>" alt="<?php echo e($recentPost->title); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend/assets/images/blog/post1-1.png')); ?>"
                                                alt="<?php echo e($recentPost->title); ?>">
                                        <?php endif; ?>
                                        <span class="sub-title"><?php echo e($recentPost->formatted_date); ?></span>
                                        <h4 class="title"><a href='<?php echo e(route('blog.single', $recentPost->slug)); ?>'
                                                title><?php echo e(Str::limit($recentPost->title, 40)); ?></a></h4>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <?php if($blog->tags && count($blog->tags) > 0): ?>
                            <div class="tag-list-widget side-widget2">
                                <h4 class="side-bar-title">Tags</h4>
                                <ul class="tag-list">
                                    <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="#" title="">/ <?php echo e($tag); ?> /</a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="strategy-widget side-widget">
                            <img src="<?php echo e(asset('frontend/assets/images/event/shades.png')); ?>" alt="Spectrum Robotics">
                            <div class="strategy-content">
                                <h4 class="title">Robotics Solutions</h4>
                                <p>Discover our range of robotics solutions for your business</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End blog-sec4 -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contact_section'); ?>
    <?php echo $__env->make('partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Robotlab\robot\resources\views/frontend/blog-single.blade.php ENDPATH**/ ?>