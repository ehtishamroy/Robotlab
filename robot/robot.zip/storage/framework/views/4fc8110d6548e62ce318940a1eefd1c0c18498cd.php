<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH C:\xampp8.0\htdocs\Robotlab\robot\vendor\orchid\platform\resources\views/partials/notification-wrap.blade.php ENDPATH**/ ?>